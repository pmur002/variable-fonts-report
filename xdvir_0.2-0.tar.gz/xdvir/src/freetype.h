
#include <R.h>
#include <Rinternals.h>

#include <ft2build.h>
#include FT_FREETYPE_H

SEXP glyphMetrics(SEXP font);

SEXP glyphIndex(SEXP code, SEXP font);
